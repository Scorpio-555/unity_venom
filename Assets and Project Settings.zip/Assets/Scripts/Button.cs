using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Button : MonoBehaviour
{
    Animator anim;
    public bool hit;
    public int timer;
    
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("I'm awake");
        anim = gameObject.GetComponent<Animator>();
        hit = false;
        timer = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if (timer > 0)
        {
            timer = timer - 1;
        }
        else if (hit)
        {
            hit = false;
        }

        if (anim.GetBool("Hit") && hit == false)
        {
            anim.SetBool("Hit", false);
        }
        else if (anim.GetBool("Hit") == false && hit)
        {
            anim.SetBool("Hit", true);
        }
    }

    void OnTriggerEnter2D(Collider2D collider)
    {
        Debug.Log("it worked");
        hit = true;
        timer = 800;
    }
}
